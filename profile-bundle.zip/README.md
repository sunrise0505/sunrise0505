# 👋 Hi ~ 我是 小羊不当咸鱼

> 用 Python 写点有趣的东西，也在探索 Agent 能做什么。

## 🌸 About me

- 🏫 **山东大学 · 软件工程**
- 🐍 主要方向：**Python / AI Agent**
- 🤖 关注 **LangChain、LangGraph、RAG、MCP**，探索工具调用与工作流编排。
- 📝 在这里记录学习笔记、小工具和 Agent 实验。
- 🎮 喜欢《物华弥新》，尤其是 **蝠桃瓶、金瓯永固杯**。

## 🛠️ Coding & Tools

<p>
  <a href="https://skillicons.dev"><img src="./assets/tools.svg" height="48" alt="Python, FastAPI, Git, GitHub, VS Code, Docker" /></a>
</p>
<p>
  <img src="./assets/langchain.svg" height="26" alt="LangChain" />
  <img src="./assets/langgraph.svg" height="26" alt="LangGraph" />
  <img src="./assets/rag.svg" height="26" alt="RAG" />
  <img src="./assets/mcp.svg" height="26" alt="MCP" />
</p>

<sub>工具与学习方向，持续探索中。</sub>

## 📊 GitHub Stats

<p>
  <img src="./assets/stats.svg" width="49%" alt="GitHub 公开仓库、Stars 和年度贡献统计" />
  <img src="./assets/languages.svg" width="49%" alt="公开非 fork 仓库的代码语言分布" />
</p>

## 🌱 Contributions

<p>
  <img src="./assets/contributions.svg" width="100%" alt="过去一年的 GitHub 贡献日历" />
  <img src="./assets/snake.svg" width="100%" alt="贡献日历贪吃蛇动画" />
</p>

---

<p align="center"><sub>慢慢积累，把想法写成代码。</sub></p>
