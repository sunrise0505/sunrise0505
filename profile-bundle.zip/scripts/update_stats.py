"""Generate light SVG cards using public GitHub data; Python standard library only."""
import json, os, urllib.request, html
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets'
USER = os.environ.get('PROFILE_USER', 'sunrise0505')

def gql(query, variables):
    request = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': query, 'variables': variables}).encode(), headers={'Authorization': 'Bearer ' + os.environ['GH_TOKEN'], 'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=40) as response:
        result = json.load(response)
    if result.get('errors'):
        raise RuntimeError(result['errors'])
    return result['data']['user']

def collect():
    user = gql('''query($login:String!){user(login:$login){contributionsCollection{contributionCalendar{totalContributions weeks{contributionDays{date contributionCount color}}}}}}''', {'login': USER})
    repos, after = [], None
    while True:
        page = gql('''query($login:String!,$after:String){user(login:$login){repositories(first:100,after:$after,privacy:PUBLIC,ownerAffiliations:OWNER){nodes{isFork stargazerCount languages(first:100){edges{size node{name color}}}} pageInfo{hasNextPage endCursor}}}}''', {'login': USER, 'after': after})['repositories']
        repos.extend(page['nodes'])
        if not page['pageInfo']['hasNextPage']:
            break
        after = page['pageInfo']['endCursor']
    own = [repo for repo in repos if not repo['isFork']]
    langs = {}
    for repo in own:
        for edge in repo['languages']['edges']:
            node = edge['node']
            entry = langs.setdefault(node['name'], {'size': 0, 'color': node['color'] or '#8b8bba'})
            entry['size'] += edge['size']
    return {'calendar': user['contributionsCollection']['contributionCalendar'], 'repos': len(repos), 'stars': sum(repo['stargazerCount'] for repo in own), 'languages': langs, 'updated': datetime.now(timezone.utc).strftime('%Y-%m-%d')}

def text(x, y, value, size=14, color='#57606a', bold=False):
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{600 if bold else 400}">{html.escape(str(value))}</text>'

def frame(width, height, title, content):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-label="{html.escape(title)}"><style>text{{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,PingFang SC,Arial,sans-serif}}</style><rect x=".5" y=".5" width="{width-1}" height="{height-1}" rx="10" fill="#fff" stroke="#d8dee4"/>{text(24,34,title,19,'#7861ab',True)}{content}</svg>'

def render(data):
    ASSETS.mkdir(exist_ok=True)
    rows = [('Public repositories', data['repos']), ('Stars · non-fork repositories', data['stars']), ('Contributions · past year', data['calendar']['totalContributions'])]
    content = ''
    for i, (label, value) in enumerate(rows):
        y = 76 + i * 36
        content += f'<circle cx="30" cy="{y-5}" r="4" fill="{["#a58bc9","#79b8a7","#e6b77c"][i]}"/>' + text(46,y,label,13) + text(360,y,value,19,'#24292f',True)
    content += text(24,191,'Public data · ' + data['updated'],11,'#8c959f')
    (ASSETS/'stats.svg').write_text(frame(440,210,'GitHub Stats',content))
    entries = sorted(data['languages'].items(), key=lambda pair: pair[1]['size'], reverse=True)
    if not entries:
        content = text(24,92,'No public code data yet',17,'#57606a',True) + text(24,124,'Languages appear after code is published.',12) + text(24,191,'Non-fork public repositories only',11,'#8c959f')
    else:
        total = sum(item['size'] for _,item in entries)
        x, content = 24, ''
        for name, info in entries:
            width = 392 * info['size'] / total
            content += f'<rect x="{x}" y="63" width="{width}" height="12" fill="{info["color"]}"/>'
            x += width
        for i, (name, info) in enumerate(entries[:4]):
            x, y = 24 + (i%2)*196, 111+(i//2)*36
            content += f'<circle cx="{x+4}" cy="{y-5}" r="4" fill="{info["color"]}"/>' + text(x+16,y,f'{name} {info["size"]/total:.1%}',12)
        content += text(24,191,'Share of code bytes · public non-fork repos',10,'#8c959f')
    (ASSETS/'languages.svg').write_text(frame(440,210,'Most Used Languages',content))
    weeks = data['calendar']['weeks']
    if weeks:
        content = ''
        for x, week in enumerate(weeks):
            for day in week['contributionDays']:
                from datetime import date
                y = (date.fromisoformat(day['date']).weekday()+1)%7
                content += f'<rect x="{32+x*16}" y="{54+y*16}" width="12" height="12" rx="2" fill="{day["color"]}"><title>{day["date"]}: {day["contributionCount"]} contributions</title></rect>'
        content += text(32,191,str(data['calendar']['totalContributions'])+' contributions in the past year',12)
    else:
        content = text(32,100,'Contribution calendar is ready to connect.',16,'#57606a',True) + text(32,133,'Run the included GitHub Actions workflow after uploading.',13) + text(32,191,'No sample activity or fabricated contributions.',11,'#8c959f')
    (ASSETS/'contributions.svg').write_text(frame(900,215,'Contribution Calendar',content))

if __name__ == '__main__':
    if os.environ.get('PROFILE_PREVIEW') == '1':
        # Initial public-profile snapshot observed on 2026-11-01. Calendar details await synchronization.
        data = {'repos':0,'stars':0,'calendar':{'totalContributions':1,'weeks':[]},'languages':{},'updated':'2026-11-01'}
    else:
        data = collect()
    render(data)
